package main

import (
	"fmt"
	pb "service/srv/proto/test"
	"context"
	client "github.com/micro/go-micro/client"	
)


func main(){


	cli := pb.NewTestService("go.micro.srv.test", client.DefaultClient)

	rsp,err := cli.Call(context.TODO(),&pb.Request{Name:"abc"})
	
	if err != nil {
		fmt.Println("err:",err.Error())
		return
	}

	fmt.Println("rsp:",rsp)
}
