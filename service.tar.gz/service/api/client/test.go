package client

import (
	"context"

	"github.com/micro/go-micro"
	"github.com/micro/go-micro/server"
	test "service/srv/proto/test"
)

type testKey struct {}

// FromContext retrieves the client from the Context
func TestFromContext(ctx context.Context) (test.TestService, bool) {
	c, ok := ctx.Value(testKey{}).(test.TestService)
	return c, ok
}

// Client returns a wrapper for the TestClient
func TestWrapper(service micro.Service) server.HandlerWrapper {
	client := test.NewTestService("go.micro.srv.test", service.Client())

	return func(fn server.HandlerFunc) server.HandlerFunc {
		return func(ctx context.Context, req server.Request, rsp interface{}) error {
			ctx = context.WithValue(ctx, testKey{}, client)
			return fn(ctx, req, rsp)
		}
	}
}
