package handler

import (
	"context"
	"encoding/json"
	"github.com/micro/go-micro/util/log"

	"service/api/client"
	"github.com/micro/go-micro/errors"
	api "github.com/micro/go-micro/api/proto"
	test "service/srv/proto/test"
)

type Body struct {
	Name string `json:"name"`
}

type Test struct{}

func extractValue(pair *api.Pair) string {
	if pair == nil {
		return ""
	}
	if len(pair.Values) == 0 {
		return ""
	}
	return pair.Values[0]
}

// Test.Call is called by the API as /test/call with post body {"name": "foo"}
func (e *Test) Call(ctx context.Context, req *api.Request, rsp *api.Response) error {
	log.Log("Received Test.Call request")

	// extract the client from the context
	testClient, ok := client.TestFromContext(ctx)
	if !ok {
		return errors.InternalServerError("go.micro.api.test.test.call", "test client not found")
	}

	body := &Body{}
	json.Unmarshal([]byte(req.Body),body)
	// make request
	response, err := testClient.Call(ctx, &test.Request{
		//Name: extractValue(req.Post["name"]),
		Name: body.Name,
	})
	if err != nil {
		return errors.InternalServerError("go.micro.api.test.test.call", err.Error())
	}

	b, _ := json.Marshal(response)

	rsp.StatusCode = 200
	rsp.Body = string(b)

	return nil
}
