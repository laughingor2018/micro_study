package main

import (
	"github.com/micro/go-micro/util/log"

	"github.com/micro/go-micro"
	"service/api/handler"
	"service/api/client"

	test "service/api/proto/test"
)

func main() {
	// New Service
	service := micro.NewService(
		micro.Name("go.micro.api.test"),
		micro.Version("latest"),
	)

	// Initialise service
	service.Init(
		// create wrap for the Test srv client
		micro.WrapHandler(client.TestWrapper(service)),
	)

	// Register Handler
	test.RegisterTestHandler(service.Server(), new(handler.Test))

	// Run service
	if err := service.Run(); err != nil {
		log.Fatal(err)
	}
}
